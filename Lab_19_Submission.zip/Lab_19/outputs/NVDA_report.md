# NVDA — NVIDIA CORP
As of 2026-11-05. USD millions except ROE. Only 10-K, annual flows.
ROE uses year-end equity. Owner earnings = operating cash flow - total capital spending.
Tag priority is applied per period, then the latest filing for that tag wins.
| Fiscal year end | Revenue | Net income | Operating cash flow | Capital spending | Equity | Liabilities | R&D | ROE | Owner earnings |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2022-01-30 | 26,914 | 9,752 | 9,108 | 976 | 26,612 | 17,575 | 5,268 | 36.6% | 8,132 |
| 2023-01-29 | 26,974 | 4,368 | 5,641 | 1,833 | 22,101 | 19,081 | 7,339 | 19.8% | 3,808 |
| 2024-01-28 | 60,922 | 29,760 | 28,090 | 1,069 | 42,978 | 22,750 | 8,675 | 69.2% | 27,021 |
| 2025-01-26 | 130,497 | 72,880 | 64,089 | 3,236 | 79,327 | 32,274 | 12,914 | 91.9% | 60,853 |
| 2026-01-25 | 215,938 | 120,067 | 102,718 | 6,042 | 157,293 | 49,510 | 18,497 | 76.3% | 96,676 |

## Tags and provenance

### 2022-01-30
- revenue: 26,914; us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; start 2021-02-01; filed 2022-03-18; accession 0001045810-22-000036
- net_income: 9,752; us-gaap:NetIncomeLoss; start 2021-02-01; filed 2024-02-21; accession 0001045810-24-000029
- operating_cash_flow: 9,108; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2021-02-01; filed 2024-02-21; accession 0001045810-24-000029
- capital_spending: 976; us-gaap:PaymentsToAcquireProductiveAssets; start 2021-02-01; filed 2024-02-21; accession 0001045810-24-000029
- equity: 26,612; us-gaap:StockholdersEquity; start instant; filed 2025-02-26; accession 0001045810-25-000023
- liabilities: 17,575; us-gaap:Liabilities; start instant; filed 2023-02-24; accession 0001045810-23-000017
- research_and_development: 5,268; us-gaap:ResearchAndDevelopmentExpense; start 2021-02-01; filed 2024-02-21; accession 0001045810-24-000029
- roe: 36.6%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: 8,132; us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquireProductiveAssets

### 2023-01-29
- revenue: 26,974; us-gaap:Revenues; start 2022-01-31; filed 2025-02-26; accession 0001045810-25-000023
- net_income: 4,368; us-gaap:NetIncomeLoss; start 2022-01-31; filed 2025-02-26; accession 0001045810-25-000023
- operating_cash_flow: 5,641; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2022-01-31; filed 2025-02-26; accession 0001045810-25-000023
- capital_spending: 1,833; us-gaap:PaymentsToAcquireProductiveAssets; start 2022-01-31; filed 2025-02-26; accession 0001045810-25-000023
- equity: 22,101; us-gaap:StockholdersEquity; start instant; filed 2026-02-25; accession 0001045810-26-000021
- liabilities: 19,081; us-gaap:Liabilities; start instant; filed 2024-02-21; accession 0001045810-24-000029
- research_and_development: 7,339; us-gaap:ResearchAndDevelopmentExpense; start 2022-01-31; filed 2025-02-26; accession 0001045810-25-000023
- roe: 19.8%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: 3,808; us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquireProductiveAssets

### 2024-01-28
- revenue: 60,922; us-gaap:Revenues; start 2023-01-30; filed 2026-02-25; accession 0001045810-26-000021
- net_income: 29,760; us-gaap:NetIncomeLoss; start 2023-01-30; filed 2026-02-25; accession 0001045810-26-000021
- operating_cash_flow: 28,090; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2023-01-30; filed 2026-02-25; accession 0001045810-26-000021
- capital_spending: 1,069; us-gaap:PaymentsToAcquireProductiveAssets; start 2023-01-30; filed 2026-02-25; accession 0001045810-26-000021
- equity: 42,978; us-gaap:StockholdersEquity; start instant; filed 2026-02-25; accession 0001045810-26-000021
- liabilities: 22,750; us-gaap:Liabilities; start instant; filed 2025-02-26; accession 0001045810-25-000023
- research_and_development: 8,675; us-gaap:ResearchAndDevelopmentExpense; start 2023-01-30; filed 2026-02-25; accession 0001045810-26-000021
- roe: 69.2%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: 27,021; us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquireProductiveAssets

### 2025-01-26
- revenue: 130,497; us-gaap:Revenues; start 2024-01-29; filed 2026-02-25; accession 0001045810-26-000021
- net_income: 72,880; us-gaap:NetIncomeLoss; start 2024-01-29; filed 2026-02-25; accession 0001045810-26-000021
- operating_cash_flow: 64,089; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2024-01-29; filed 2026-02-25; accession 0001045810-26-000021
- capital_spending: 3,236; us-gaap:PaymentsToAcquireProductiveAssets; start 2024-01-29; filed 2026-02-25; accession 0001045810-26-000021
- equity: 79,327; us-gaap:StockholdersEquity; start instant; filed 2026-02-25; accession 0001045810-26-000021
- liabilities: 32,274; us-gaap:Liabilities; start instant; filed 2026-02-25; accession 0001045810-26-000021
- research_and_development: 12,914; us-gaap:ResearchAndDevelopmentExpense; start 2024-01-29; filed 2026-02-25; accession 0001045810-26-000021
- roe: 91.9%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: 60,853; us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquireProductiveAssets

### 2026-01-25
- revenue: 215,938; us-gaap:Revenues; start 2025-01-27; filed 2026-02-25; accession 0001045810-26-000021
- net_income: 120,067; us-gaap:NetIncomeLoss; start 2025-01-27; filed 2026-02-25; accession 0001045810-26-000021
- operating_cash_flow: 102,718; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2025-01-27; filed 2026-02-25; accession 0001045810-26-000021
- capital_spending: 6,042; us-gaap:PaymentsToAcquireProductiveAssets; start 2025-01-27; filed 2026-02-25; accession 0001045810-26-000021
- equity: 157,293; us-gaap:StockholdersEquity; start instant; filed 2026-02-25; accession 0001045810-26-000021
- liabilities: 49,510; us-gaap:Liabilities; start instant; filed 2026-02-25; accession 0001045810-26-000021
- research_and_development: 18,497; us-gaap:ResearchAndDevelopmentExpense; start 2025-01-27; filed 2026-02-25; accession 0001045810-26-000021
- roe: 76.3%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: 96,676; us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquireProductiveAssets

## Computed checks
- ROE >= 15% every year: pass
- Owner earnings positive every year: pass
- Owner earnings grew first to last: pass

## Panel inputs and calculations
USD millions; ratios dimensionless.
| Fiscal year end | Liabilities | R&D | R&D / revenue | Liabilities / equity |
|---|---:|---:|---:|---:|
| 2022-01-30 | 17,575 | 5,268 | 19.57% | 0.66 |
| 2023-01-29 | 19,081 | 7,339 | 27.21% | 0.86 |
| 2024-01-28 | 22,750 | 8,675 | 14.24% | 0.53 |
| 2025-01-26 | 32,274 | 12,914 | 9.90% | 0.41 |
| 2026-01-25 | 49,510 | 18,497 | 8.57% | 0.31 |

Revenue CAGR = (last / first)^(1/4) - 1: 68.30%.
Growth threshold: 15%. R&D threshold: 5%. Liabilities / equity ceiling: 2.

| Investor | Check | Result |
|---|---|---|
| Buffett | ROE >= 15% every year | pass |
| Buffett | Owner earnings positive every year | pass |
| Buffett | Owner earnings grew first to last | pass |
| Cathie Wood | Revenue CAGR >= 15% first to last | pass |
| Cathie Wood | Latest R&D / revenue >= 5% | pass |
| Burry | OCF >= net income every year | fail |
| Burry | Latest liabilities / equity <= 2 | pass |
