# JPM - wood memo

AI educational interpretation, not the investor's actual opinion. Evidence: the shared script-generated report only.

**Verdict: pass on this growth screen.** Revenue CAGR is 10.66%, below 15%. R&D is not found and its intensity check is not known. A bank can have valuable innovation without separate reporting under the permitted tag; the screen's sector fit is uncertain. I would require bank-specific analysis rather than substitute estimates for the gap.

Threshold kept: 15%; retain the lab hurdle rather than tune it to make COST pass.
