# JPM — JPMORGAN CHASE & CO
As of 2026-11-05. USD millions except ROE. Only 10-K, annual flows.
ROE uses year-end equity. Owner earnings = operating cash flow - total capital spending.
Tag priority is applied per period, then the latest filing for that tag wins.
| Fiscal year end | Revenue | Net income | Operating cash flow | Capital spending | Equity | Liabilities | R&D | ROE | Owner earnings |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2021-12-31 | 121,649 | 48,334 | 78,084 | not found | 294,127 | 3,449,440 | not found | 16.4% | not found |
| 2022-12-31 | 128,695 | 37,676 | 107,119 | not found | 292,332 | 3,373,411 | not found | 12.9% | not found |
| 2023-12-31 | 158,104 | 49,552 | 12,974 | not found | 327,878 | 3,547,515 | not found | 15.1% | not found |
| 2024-12-31 | 177,556 | 58,471 | -42,012 | not found | 344,758 | 3,658,056 | not found | 17.0% | not found |
| 2025-12-31 | 182,447 | 57,048 | -147,782 | not found | 362,438 | 4,062,462 | not found | 15.7% | not found |

## Tags and provenance

### 2021-12-31
- revenue: 121,649; us-gaap:Revenues; start 2021-01-01; filed 2024-02-16; accession 0000019617-24-000225
- net_income: 48,334; us-gaap:NetIncomeLoss; start 2021-01-01; filed 2024-02-16; accession 0000019617-24-000225
- operating_cash_flow: 78,084; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2021-01-01; filed 2024-02-16; accession 0000019617-24-000225
- capital_spending: not found; not found
- equity: 294,127; us-gaap:StockholdersEquity; start instant; filed 2024-02-16; accession 0000019617-24-000225
- liabilities: 3,449,440; us-gaap:Liabilities; start instant; filed 2023-02-21; accession 0000019617-23-000231
- research_and_development: not found; not found
- roe: 16.4%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: not found; us-gaap:NetCashProvidedByUsedInOperatingActivities - not found

### 2022-12-31
- revenue: 128,695; us-gaap:Revenues; start 2022-01-01; filed 2025-02-14; accession 0000019617-25-000270
- net_income: 37,676; us-gaap:NetIncomeLoss; start 2022-01-01; filed 2025-02-14; accession 0000019617-25-000270
- operating_cash_flow: 107,119; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2022-01-01; filed 2025-02-14; accession 0000019617-25-000270
- capital_spending: not found; not found
- equity: 292,332; us-gaap:StockholdersEquity; start instant; filed 2025-02-14; accession 0000019617-25-000270
- liabilities: 3,373,411; us-gaap:Liabilities; start instant; filed 2024-02-16; accession 0000019617-24-000225
- research_and_development: not found; not found
- roe: 12.9%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: not found; us-gaap:NetCashProvidedByUsedInOperatingActivities - not found

### 2023-12-31
- revenue: 158,104; us-gaap:Revenues; start 2023-01-01; filed 2026-02-13; accession 0001628280-26-008131
- net_income: 49,552; us-gaap:NetIncomeLoss; start 2023-01-01; filed 2026-02-13; accession 0001628280-26-008131
- operating_cash_flow: 12,974; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2023-01-01; filed 2026-02-13; accession 0001628280-26-008131
- capital_spending: not found; not found
- equity: 327,878; us-gaap:StockholdersEquity; start instant; filed 2026-02-13; accession 0001628280-26-008131
- liabilities: 3,547,515; us-gaap:Liabilities; start instant; filed 2025-02-14; accession 0000019617-25-000270
- research_and_development: not found; not found
- roe: 15.1%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: not found; us-gaap:NetCashProvidedByUsedInOperatingActivities - not found

### 2024-12-31
- revenue: 177,556; us-gaap:Revenues; start 2024-01-01; filed 2026-02-13; accession 0001628280-26-008131
- net_income: 58,471; us-gaap:NetIncomeLoss; start 2024-01-01; filed 2026-02-13; accession 0001628280-26-008131
- operating_cash_flow: -42,012; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2024-01-01; filed 2026-02-13; accession 0001628280-26-008131
- capital_spending: not found; not found
- equity: 344,758; us-gaap:StockholdersEquity; start instant; filed 2026-02-13; accession 0001628280-26-008131
- liabilities: 3,658,056; us-gaap:Liabilities; start instant; filed 2026-02-13; accession 0001628280-26-008131
- research_and_development: not found; not found
- roe: 17.0%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: not found; us-gaap:NetCashProvidedByUsedInOperatingActivities - not found

### 2025-12-31
- revenue: 182,447; us-gaap:Revenues; start 2025-01-01; filed 2026-02-13; accession 0001628280-26-008131
- net_income: 57,048; us-gaap:NetIncomeLoss; start 2025-01-01; filed 2026-02-13; accession 0001628280-26-008131
- operating_cash_flow: -147,782; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2025-01-01; filed 2026-02-13; accession 0001628280-26-008131
- capital_spending: not found; not found
- equity: 362,438; us-gaap:StockholdersEquity; start instant; filed 2026-02-13; accession 0001628280-26-008131
- liabilities: 4,062,462; us-gaap:Liabilities; start instant; filed 2026-02-13; accession 0001628280-26-008131
- research_and_development: not found; not found
- roe: 15.7%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: not found; us-gaap:NetCashProvidedByUsedInOperatingActivities - not found

## Computed checks
- ROE >= 15% every year: fail
- Owner earnings positive every year: not known
- Owner earnings grew first to last: not known

## Panel inputs and calculations
USD millions; ratios dimensionless.
| Fiscal year end | Liabilities | R&D | R&D / revenue | Liabilities / equity |
|---|---:|---:|---:|---:|
| 2021-12-31 | 3,449,440 | not found | not known | 11.73 |
| 2022-12-31 | 3,373,411 | not found | not known | 11.54 |
| 2023-12-31 | 3,547,515 | not found | not known | 10.82 |
| 2024-12-31 | 3,658,056 | not found | not known | 10.61 |
| 2025-12-31 | 4,062,462 | not found | not known | 11.21 |

Revenue CAGR = (last / first)^(1/4) - 1: 10.66%.
Growth threshold: 15%. R&D threshold: 5%. Liabilities / equity ceiling: 2.

| Investor | Check | Result |
|---|---|---|
| Buffett | ROE >= 15% every year | fail |
| Buffett | Owner earnings positive every year | not known |
| Buffett | Owner earnings grew first to last | not known |
| Cathie Wood | Revenue CAGR >= 15% first to last | fail |
| Cathie Wood | Latest R&D / revenue >= 5% | not known |
| Burry | OCF >= net income every year | fail |
| Burry | Latest liabilities / equity <= 2 | fail |
