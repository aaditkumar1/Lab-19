# COST — COSTCO WHOLESALE CORP /NEW
As of 2026-11-05. USD millions except ROE. Only 10-K, annual flows.
ROE uses year-end equity. Owner earnings = operating cash flow - total capital spending.
Tag priority is applied per period, then the latest filing for that tag wins.
| Fiscal year end | Revenue | Net income | Operating cash flow | Capital spending | Equity | Liabilities | R&D | ROE | Owner earnings |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2022-08-28 | 226,954 | 5,844 | 7,392 | 3,891 | 20,642 | 43,519 | not found | 28.3% | 3,501 |
| 2023-09-03 | 242,290 | 6,292 | 11,068 | 4,323 | 25,058 | 43,936 | not found | 25.1% | 6,745 |
| 2024-09-01 | 254,453 | 7,367 | 11,339 | 4,710 | 23,622 | 46,209 | not found | 31.2% | 6,629 |
| 2025-08-31 | 275,235 | 8,099 | 13,335 | 5,498 | 29,164 | 47,935 | not found | 27.8% | 7,837 |
| 2026-08-30 | 303,154 | 9,226 | 15,817 | 6,435 | 35,803 | 53,242 | not found | 25.8% | 9,382 |

## Tags and provenance

### 2022-08-28
- revenue: 226,954; us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; start 2021-08-30; filed 2024-10-09; accession 0000909832-24-000049
- net_income: 5,844; us-gaap:NetIncomeLoss; start 2021-08-30; filed 2024-10-09; accession 0000909832-24-000049
- operating_cash_flow: 7,392; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2021-08-30; filed 2024-10-09; accession 0000909832-24-000049
- capital_spending: 3,891; us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; start 2021-08-30; filed 2024-10-09; accession 0000909832-24-000049
- equity: 20,642; us-gaap:StockholdersEquity; start instant; filed 2023-10-11; accession 0000909832-23-000042
- liabilities: 43,519; us-gaap:Liabilities; start instant; filed 2023-10-11; accession 0000909832-23-000042
- research_and_development: not found; not found
- roe: 28.3%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: 3,501; us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment

### 2023-09-03
- revenue: 242,290; us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; start 2022-08-29; filed 2025-10-08; accession 0000909832-25-000101
- net_income: 6,292; us-gaap:NetIncomeLoss; start 2022-08-29; filed 2025-10-08; accession 0000909832-25-000101
- operating_cash_flow: 11,068; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2022-08-29; filed 2025-10-08; accession 0000909832-25-000101
- capital_spending: 4,323; us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; start 2022-08-29; filed 2025-10-08; accession 0000909832-25-000101
- equity: 25,058; us-gaap:StockholdersEquity; start instant; filed 2026-10-07; accession 0000909832-26-000093
- liabilities: 43,936; us-gaap:Liabilities; start instant; filed 2024-10-09; accession 0000909832-24-000049
- research_and_development: not found; not found
- roe: 25.1%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: 6,745; us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment

### 2024-09-01
- revenue: 254,453; us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; start 2023-09-04; filed 2026-10-07; accession 0000909832-26-000093
- net_income: 7,367; us-gaap:NetIncomeLoss; start 2023-09-04; filed 2026-10-07; accession 0000909832-26-000093
- operating_cash_flow: 11,339; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2023-09-04; filed 2026-10-07; accession 0000909832-26-000093
- capital_spending: 4,710; us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; start 2023-09-04; filed 2026-10-07; accession 0000909832-26-000093
- equity: 23,622; us-gaap:StockholdersEquity; start instant; filed 2026-10-07; accession 0000909832-26-000093
- liabilities: 46,209; us-gaap:Liabilities; start instant; filed 2025-10-08; accession 0000909832-25-000101
- research_and_development: not found; not found
- roe: 31.2%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: 6,629; us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment

### 2025-08-31
- revenue: 275,235; us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; start 2024-09-02; filed 2026-10-07; accession 0000909832-26-000093
- net_income: 8,099; us-gaap:NetIncomeLoss; start 2024-09-02; filed 2026-10-07; accession 0000909832-26-000093
- operating_cash_flow: 13,335; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2024-09-02; filed 2026-10-07; accession 0000909832-26-000093
- capital_spending: 5,498; us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; start 2024-09-02; filed 2026-10-07; accession 0000909832-26-000093
- equity: 29,164; us-gaap:StockholdersEquity; start instant; filed 2026-10-07; accession 0000909832-26-000093
- liabilities: 47,935; us-gaap:Liabilities; start instant; filed 2026-10-07; accession 0000909832-26-000093
- research_and_development: not found; not found
- roe: 27.8%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: 7,837; us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment

### 2026-08-30
- revenue: 303,154; us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; start 2025-09-01; filed 2026-10-07; accession 0000909832-26-000093
- net_income: 9,226; us-gaap:NetIncomeLoss; start 2025-09-01; filed 2026-10-07; accession 0000909832-26-000093
- operating_cash_flow: 15,817; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2025-09-01; filed 2026-10-07; accession 0000909832-26-000093
- capital_spending: 6,435; us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; start 2025-09-01; filed 2026-10-07; accession 0000909832-26-000093
- equity: 35,803; us-gaap:StockholdersEquity; start instant; filed 2026-10-07; accession 0000909832-26-000093
- liabilities: 53,242; us-gaap:Liabilities; start instant; filed 2026-10-07; accession 0000909832-26-000093
- research_and_development: not found; not found
- roe: 25.8%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: 9,382; us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment

## Computed checks
- ROE >= 15% every year: pass
- Owner earnings positive every year: pass
- Owner earnings grew first to last: pass

## Panel inputs and calculations
USD millions; ratios dimensionless.
| Fiscal year end | Liabilities | R&D | R&D / revenue | Liabilities / equity |
|---|---:|---:|---:|---:|
| 2022-08-28 | 43,519 | not found | not known | 2.11 |
| 2023-09-03 | 43,936 | not found | not known | 1.75 |
| 2024-09-01 | 46,209 | not found | not known | 1.96 |
| 2025-08-31 | 47,935 | not found | not known | 1.64 |
| 2026-08-30 | 53,242 | not found | not known | 1.49 |

Revenue CAGR = (last / first)^(1/4) - 1: 7.51%.
Growth threshold: 15%. R&D threshold: 5%. Liabilities / equity ceiling: 2.

| Investor | Check | Result |
|---|---|---|
| Buffett | ROE >= 15% every year | pass |
| Buffett | Owner earnings positive every year | pass |
| Buffett | Owner earnings grew first to last | pass |
| Cathie Wood | Revenue CAGR >= 15% first to last | fail |
| Cathie Wood | Latest R&D / revenue >= 5% | not known |
| Burry | OCF >= net income every year | pass |
| Burry | Latest liabilities / equity <= 2 | pass |
