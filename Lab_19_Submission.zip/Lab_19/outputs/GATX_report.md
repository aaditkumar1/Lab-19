# GATX — GATX CORP
As of 2026-11-05. USD millions except ROE. Only 10-K, annual flows.
ROE uses year-end equity. Owner earnings = operating cash flow - total capital spending.
Tag priority is applied per period, then the latest filing for that tag wins.
| Fiscal year end | Revenue | Net income | Operating cash flow | Capital spending | Equity | Liabilities | R&D | ROE | Owner earnings |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2021-12-31 | 1,257.4 | 143.1 | 507.2 | 1,130.1 | 2,019.2 | 7,522.5 | not found | 7.1% | -622.9 |
| 2022-12-31 | 1,273 | 155.9 | 533.5 | 1,255.8 | 2,029.6 | 8,042.4 | not found | 7.7% | -722.3 |
| 2023-12-31 | 1,410.9 | 259.2 | 520.4 | 1,665 | 2,273 | 9,053 | not found | 11.4% | -1,144.6 |
| 2024-12-31 | 1,585.5 | 284.2 | 602.1 | not found | 2,438.9 | 9,857.6 | not found | 11.7% | not found |
| 2025-12-31 | 1,740.4 | 333.3 | 648.1 | not found | 2,750.5 | 14,364.4 | not found | 12.1% | not found |

## Tags and provenance

### 2021-12-31
- revenue: 1,257.4; us-gaap:Revenues; start 2021-01-01; filed 2024-02-16; accession 0000040211-24-000023
- net_income: 143.1; us-gaap:NetIncomeLoss; start 2021-01-01; filed 2024-02-16; accession 0000040211-24-000023
- operating_cash_flow: 507.2; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2021-01-01; filed 2024-02-16; accession 0000040211-24-000023
- capital_spending: 1,130.1; us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; start 2021-01-01; filed 2024-02-16; accession 0000040211-24-000023
- equity: 2,019.2; us-gaap:StockholdersEquity; start instant; filed 2024-02-16; accession 0000040211-24-000023
- liabilities: 7,522.5; us-gaap:Liabilities; start instant; filed 2023-02-16; accession 0000040211-23-000023
- research_and_development: not found; not found
- roe: 7.1%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: -622.9; us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment

### 2022-12-31
- revenue: 1,273; us-gaap:Revenues; start 2022-01-01; filed 2025-02-19; accession 0000040211-25-000024
- net_income: 155.9; us-gaap:NetIncomeLoss; start 2022-01-01; filed 2025-02-19; accession 0000040211-25-000024
- operating_cash_flow: 533.5; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2022-01-01; filed 2025-02-19; accession 0000040211-25-000024
- capital_spending: 1,255.8; us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; start 2022-01-01; filed 2024-02-16; accession 0000040211-24-000023
- equity: 2,029.6; us-gaap:StockholdersEquity; start instant; filed 2025-02-19; accession 0000040211-25-000024
- liabilities: 8,042.4; us-gaap:Liabilities; start instant; filed 2024-02-16; accession 0000040211-24-000023
- research_and_development: not found; not found
- roe: 7.7%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: -722.3; us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment

### 2023-12-31
- revenue: 1,410.9; us-gaap:Revenues; start 2023-01-01; filed 2026-02-19; accession 0000040211-26-000018
- net_income: 259.2; us-gaap:NetIncomeLoss; start 2023-01-01; filed 2026-02-19; accession 0000040211-26-000018
- operating_cash_flow: 520.4; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2023-01-01; filed 2026-02-19; accession 0000040211-26-000018
- capital_spending: 1,665; us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; start 2023-01-01; filed 2024-02-16; accession 0000040211-24-000023
- equity: 2,273; us-gaap:StockholdersEquity; start instant; filed 2025-02-19; accession 0000040211-25-000024
- liabilities: 9,053; us-gaap:Liabilities; start instant; filed 2025-02-19; accession 0000040211-25-000024
- research_and_development: not found; not found
- roe: 11.4%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: -1,144.6; us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment

### 2024-12-31
- revenue: 1,585.5; us-gaap:Revenues; start 2024-01-01; filed 2026-02-19; accession 0000040211-26-000018
- net_income: 284.2; us-gaap:NetIncomeLoss; start 2024-01-01; filed 2026-02-19; accession 0000040211-26-000018
- operating_cash_flow: 602.1; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2024-01-01; filed 2026-02-19; accession 0000040211-26-000018
- capital_spending: not found; not found
- equity: 2,438.9; us-gaap:StockholdersEquity; start instant; filed 2026-02-19; accession 0000040211-26-000018
- liabilities: 9,857.6; us-gaap:Liabilities; start instant; filed 2026-02-19; accession 0000040211-26-000018
- research_and_development: not found; not found
- roe: 11.7%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: not found; us-gaap:NetCashProvidedByUsedInOperatingActivities - not found

### 2025-12-31
- revenue: 1,740.4; us-gaap:Revenues; start 2025-01-01; filed 2026-02-19; accession 0000040211-26-000018
- net_income: 333.3; us-gaap:NetIncomeLoss; start 2025-01-01; filed 2026-02-19; accession 0000040211-26-000018
- operating_cash_flow: 648.1; us-gaap:NetCashProvidedByUsedInOperatingActivities; start 2025-01-01; filed 2026-02-19; accession 0000040211-26-000018
- capital_spending: not found; not found
- equity: 2,750.5; us-gaap:StockholdersEquity; start instant; filed 2026-02-19; accession 0000040211-26-000018
- liabilities: 14,364.4; us-gaap:Liabilities; start instant; filed 2026-02-19; accession 0000040211-26-000018
- research_and_development: not found; not found
- roe: 12.1%; us-gaap:NetIncomeLoss / us-gaap:StockholdersEquity
- owner_earnings: not found; us-gaap:NetCashProvidedByUsedInOperatingActivities - not found

## Computed checks
- ROE >= 15% every year: fail
- Owner earnings positive every year: not known
- Owner earnings grew first to last: not known

## Panel inputs and calculations
USD millions; ratios dimensionless.
| Fiscal year end | Liabilities | R&D | R&D / revenue | Liabilities / equity |
|---|---:|---:|---:|---:|
| 2021-12-31 | 7,522.5 | not found | not known | 3.73 |
| 2022-12-31 | 8,042.4 | not found | not known | 3.96 |
| 2023-12-31 | 9,053 | not found | not known | 3.98 |
| 2024-12-31 | 9,857.6 | not found | not known | 4.04 |
| 2025-12-31 | 14,364.4 | not found | not known | 5.22 |

Revenue CAGR = (last / first)^(1/4) - 1: 8.47%.
Growth threshold: 15%. R&D threshold: 5%. Liabilities / equity ceiling: 2.

| Investor | Check | Result |
|---|---|---|
| Buffett | ROE >= 15% every year | fail |
| Buffett | Owner earnings positive every year | not known |
| Buffett | Owner earnings grew first to last | not known |
| Cathie Wood | Revenue CAGR >= 15% first to last | fail |
| Cathie Wood | Latest R&D / revenue >= 5% | not known |
| Burry | OCF >= net income every year | pass |
| Burry | Latest liabilities / equity <= 2 | fail |
