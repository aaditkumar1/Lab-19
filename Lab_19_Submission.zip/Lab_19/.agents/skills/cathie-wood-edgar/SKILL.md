---
name: cathie-wood-edgar
description: Run a Cathie Wood-inspired SEC annual-facts screen and write a separate evidence-limited memo for the Legend Panel.
---

growth_threshold: 0.15

# Cathie Wood educational screen

Source inspiration: https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/cathie_wood.md
The lab uses only a small subset of that page; these thresholds are classroom design choices, not authenticated investor rules. Assess growth and research intensity. A failure means this narrow innovation screen is not met; it is not proof that innovation is absent.

Run `python panel.py TICKER` from the Lab_19 folder for the saved snapshot, or add `--live` with the user's real SEC_USER_AGENT for a new download. Read outputs/TICKER_report.md. The shared panel.py computes all checks from the same five annual 10-K periods as Buffett. No imputation. Missing raw values are not found; unavailable calculations and checks are not known.

Revenue CAGR = (last revenue / first revenue)^(1/4) - 1; require at least the growth_threshold in this skill. Latest R&D / revenue must be at least 5%. The threshold is read by code: change it to 0.05 for the probe and restore 0.15 afterward.

Write your own memo to outputs/TICKER_wood_memo.md, independently of the other memos. Label it an AI educational interpretation, not the investor's actual opinion. Choose own the business, watch it, or pass; explain evidence, strongest counterargument, gaps and what would change the verdict. Use printed numbers only with their printed precision and units. No prices, forecasts or invented business facts. Innovation and revenue growth does not establish investment value. Run panel.audit_all on every memo against the printed report and fix unsupported numbers. A numeric whitelist does not validate attribution or qualitative truth.
