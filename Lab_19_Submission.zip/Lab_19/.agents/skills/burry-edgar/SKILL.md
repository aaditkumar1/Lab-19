---
name: burry-edgar
description: Run a Michael Burry-inspired SEC annual-facts screen and write a separate evidence-limited memo for the Legend Panel.
---

# Michael Burry educational screen

Source inspiration: https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/michael_burry.md
The lab uses only a small subset of that page; these thresholds are classroom design choices, not authenticated investor rules. Assess cash support for earnings and liabilities relative to equity. Passing cannot rule out hidden liabilities, accounting problems or overvaluation.

Run `python panel.py TICKER` from the Lab_19 folder for the saved snapshot, or add `--live` with the user's real SEC_USER_AGENT for a new download. Read outputs/TICKER_report.md. The shared panel.py computes all checks from the same five annual 10-K periods as Buffett. No imputation. Missing raw values are not found; unavailable calculations and checks are not known.

Require OCF at least net income every year and latest liabilities / positive equity no more than 2. Missing or nonpositive equity makes the leverage check not known.

Write your own memo to outputs/TICKER_burry_memo.md, independently of the other memos. Label it an AI educational interpretation, not the investor's actual opinion. Choose own the business, watch it, or pass; explain evidence, strongest counterargument, gaps and what would change the verdict. Use printed numbers only with their printed precision and units. No prices, forecasts or invented business facts. Cash earnings quality and balance sheet risk does not establish investment value. Run panel.audit_all on every memo against the printed report and fix unsupported numbers. A numeric whitelist does not validate attribution or qualitative truth.
