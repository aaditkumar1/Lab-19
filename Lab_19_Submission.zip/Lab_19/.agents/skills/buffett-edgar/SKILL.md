---
name: buffett-edgar
description: Analyze a ticker as a Buffett-style business using five fiscal years of SEC 10-K company facts, deterministic financial calculations, and a saved qualitative memo. Use for Lab 18 or a repeatable business-quality screen without price data.
---

# Buffett business-quality screen

Read the philosophy at https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/warren_buffett.md as background only. Never install FAskills or use its paid data sources. Favor understandable businesses, durable competitive advantages, conservative financing, and cash earning power. The lab overrides that page's valuation, price targets, forecasts, scores, and owner-earnings definition.

Run the bundled `scripts/edgar_facts.py TICKER --out OUTPUT_DIRECTORY`. Require `SEC_USER_AGENT` to contain the user's actual name and email; do not invent contact information. The script uses keyless SEC ticker and companyfacts endpoints. For reproduction use `--as-of YYYY-MM-DD`; for a saved verified snapshot use `--offline`.

Use only script output as numerical evidence. Read the printed report and JSON before judging. Never fill missing facts from memory, other sources, or the lab answer key. Report gaps and discrepancies honestly. The script defines all arithmetic and checks; do not recalculate, round, forecast, or invent numerical scores in the memo.

Write `TICKER_memo.md` beside the report in a plain, patient Buffett-inspired voice, explicitly labeled an AI educational interpretation rather than Buffett's actual opinion. Choose **own the business**, **watch it**, or **pass** as a business-quality verdict, not a trade instruction. Explain the earning-power evidence, strongest counterargument, limitations, and what would change the judgment. Financial outputs alone cannot establish a moat, management integrity, or financing resilience. Make these unknowns explicit instead of inventing business facts. If owner earnings is unavailable, say that you cannot judge owner earnings under this screen. The lab's operating-cash-flow-minus-total-capex proxy is not Buffett's full maintenance-capital estimate.

Use numbers exactly as printed, with matching units and percent signs. No price, market cap, valuation, price targets, or unsupported claims. Then run `scripts/edgar_facts.py TICKER --out OUTPUT_DIRECTORY --offline --audit-memo OUTPUT_DIRECTORY/TICKER_memo.md`; fix every flagged number. The audit checks numeric support, not whether the number was assigned to the right metric or whether prose is true. If refreshing data changes the facts, reread and revise the memo; never silently reuse it as a current verdict.

Leave the user's personal trust decision separate from the AI verdict. A suggested decision can be supplied for review, but never claim the user or their partner performed an activity they did not report.

## Lab 19 panel
Run `python panel.py TICKER` from the Lab_19 root to include the shared panel inputs. Save the independent memo as outputs/TICKER_buffett_memo.md. Audit it with panel.audit_all together with the Wood and Burry memos. The shared driver retains the original Buffett formulas and adds the other investors without changing them.
