"""Keyless SEC 10-K facts; all financial arithmetic lives here, not in the model."""
import argparse
from datetime import date, datetime, timezone
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import re
import time
import urllib.error
import urllib.request

TICKERS_URL = 'https://www.sec.gov/files/company_tickers.json'
FACTS_URL = 'https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json'
TAGS = {
    'revenue': ['RevenueFromContractWithCustomerExcludingAssessedTax', 'Revenues'],
    'net_income': ['NetIncomeLoss'],
    'operating_cash_flow': ['NetCashProvidedByUsedInOperatingActivities'],
    'capital_spending': ['PaymentsToAcquirePropertyPlantAndEquipment', 'PaymentsToAcquireProductiveAssets'],
    'equity': ['StockholdersEquity'],
}
CHECK_NAMES = ['ROE >= 15% every year', 'Owner earnings positive every year', 'Owner earnings grew first to last']
ROOT = Path(__file__).resolve().parents[4]


def download(url, user_agent):
    """One request at a time, bounded retries; preserve response bytes for audit."""
    if not user_agent or not re.search(r'\S+@\S+\.\S+', user_agent) or len(user_agent.split()) < 2:
        raise ValueError('Set SEC_USER_AGENT to your real name and email before downloading.')
    for attempt in range(3):
        time.sleep(0.2 if attempt == 0 else 2 ** attempt)
        request = urllib.request.Request(url, headers={'User-Agent': user_agent, 'Accept': 'application/json'})
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                raw = response.read()
            json.loads(raw)  # Reject error pages before saving them as evidence.
            return raw
        except urllib.error.HTTPError as exc:
            if exc.code not in (429, 500, 502, 503, 504) or attempt == 2:
                raise RuntimeError(f'SEC HTTP {exc.code}: {url}. No alternate data or estimates used.') from exc
        except (TimeoutError, urllib.error.URLError):
            if attempt == 2:
                raise


def annual(fact):
    """Accept full calendar, 52-week, or 53-week annual flows, never quarters/YTD."""
    if not fact.get('start'):
        return False
    days = (date.fromisoformat(fact['end']) - date.fromisoformat(fact['start'])).days + 1
    return 350 <= days <= 380


def eligible(fact, as_of):
    return (fact.get('form') == '10-K' and fact.get('filed', '9999') <= as_of
            and fact.get('end', '9999') <= as_of)


def facts_for(data, tag):
    return data.get('facts', {}).get('us-gaap', {}).get(tag, {}).get('units', {}).get('USD', [])


def select_fact(data, metric, end, as_of):
    """Tag priority first; within the chosen tag and annual period, latest filing wins."""
    for tag in TAGS[metric]:
        candidates = [f for f in facts_for(data, tag)
                      if eligible(f, as_of) and f['end'] == end
                      and (not f.get('start') if metric == 'equity' else annual(f))]
        if not candidates:
            continue
        # fy/fp refer to the filing, not the comparative fact's fiscal year.
        chosen = max(candidates, key=lambda f: (f['filed'], f.get('accn', ''), f.get('start', '')))
        same = [f for f in candidates if f['filed'] == chosen['filed']
                and f.get('accn') == chosen.get('accn') and f.get('start') == chosen.get('start')]
        if len({f['val'] for f in same}) != 1:
            raise ValueError(f'Ambiguous conflicting facts: {metric} {end} {tag}')
        return {'value': chosen['val'], 'tag': 'us-gaap:' + tag,
                'start': chosen.get('start'), 'end': end, 'filed': chosen['filed'],
                'accession': chosen.get('accn'), 'unit': 'USD'}
    return {'value': None, 'tag': 'not found', 'end': end, 'unit': 'USD'}


def year_row(data, end, as_of):
    """EXPLAIN THIS FUNCTION: extract one fiscal year's inputs, then compute outputs."""
    row = {'fiscal_year_end': end}
    for metric in TAGS:
        row[metric] = select_fact(data, metric, end, as_of)
    income = row['net_income']['value']
    equity = row['equity']['value']
    ocf = row['operating_cash_flow']['value']
    capex = row['capital_spending']['value']
    # A missing value is None internally; display code renders "not found".
    row['owner_earnings'] = {'value': None if ocf is None or capex is None else ocf - capex,
                             'tag': row['operating_cash_flow']['tag'] + ' - ' + row['capital_spending']['tag'],
                             'unit': 'USD'}
    # Nonpositive equity makes this ratio uninterpretable under the assignment.
    row['roe'] = {'value': None if income is None or equity is None or equity <= 0 else income / equity,
                  'tag': row['net_income']['tag'] + ' / ' + row['equity']['tag'], 'unit': 'ratio'}
    return row


def compute_checks(rows):
    roe = [r['roe']['value'] for r in rows]
    earnings = [r['owner_earnings']['value'] for r in rows]
    def evaluate(values, predicate):
        return 'not known' if len(rows) != 5 or any(v is None for v in values) else ('pass' if predicate(values) else 'fail')
    return dict(zip(CHECK_NAMES, [evaluate(roe, lambda v: all(x >= .15 for x in v)),
                    evaluate(earnings, lambda v: all(x > 0 for x in v)),
                    evaluate(earnings, lambda v: v[-1] > v[0])]))


def analyze(data, ticker, as_of):
    # Discover annual period ends across the required flows; do not require a complete row.
    ends = sorted({f['end'] for metric in TAGS if metric != 'equity' for tag in TAGS[metric]
                   for f in facts_for(data, tag) if eligible(f, as_of) and annual(f)})[-5:]
    if not ends:
        raise ValueError('No eligible annual USD 10-K periods found.')
    rows = [year_row(data, end, as_of) for end in ends]
    return {'ticker': ticker, 'company': data.get('entityName'), 'cik': data['cik'],
            'as_of': as_of, 'rows': rows, 'checks': compute_checks(rows)}


def money(value):
    return 'not found' if value is None else f'{Decimal(str(value)) / Decimal(1000000):,.6f}'.rstrip('0').rstrip('.')


def display(metric, cell):
    if metric == 'roe':
        return 'not known' if cell['value'] is None else f"{cell['value'] * 100:.1f}%"
    return money(cell['value'])


def report_text(result):
    lines = [f"# {result['ticker']} — {result['company']}",
             f"As of {result['as_of']}. USD millions except ROE. Only 10-K, annual flows.",
             'ROE uses year-end equity. Owner earnings = operating cash flow - total capital spending.',
             'Tag priority is applied per period, then the latest filing for that tag wins.',
             '| Fiscal year end | Revenue | Net income | Operating cash flow | Capital spending | Equity | Liabilities | R&D | ROE | Owner earnings |',
             '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    metrics = list(TAGS) + ['roe', 'owner_earnings']
    for row in result['rows']:
        lines.append('| ' + row['fiscal_year_end'] + ' | ' + ' | '.join(display(m, row[m]) for m in metrics) + ' |')
    lines += ['', '## Tags and provenance']
    for row in result['rows']:
        lines.append('\n### ' + row['fiscal_year_end'])
        for metric in metrics:
            cell = row[metric]
            lines.append(f"- {metric}: {display(metric, cell)}; {cell['tag']}"
                         + (f"; start {cell.get('start') or 'instant'}; filed {cell['filed']}; accession {cell['accession']}" if cell.get('filed') else ''))
    lines += ['', '## Computed checks'] + [f'- {k}: {v}' for k, v in result['checks'].items()]
    if len(result['rows']) != 5:
        lines.append('Incomplete five-year history: checks not known.')
    return '\n'.join(lines) + '\n'


# Whole dates are a token, percentages remain distinct from money, signs matter.
NUMBER = re.compile(r'\d{4}-\d{2}-\d{2}|[+-]?(?:\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?|\.\d+)(?:[eE][+-]?\d+)?[ \t]*%?')


def numeric_tokens(text):
    tokens = []
    for match in NUMBER.finditer(text):
        literal = match.group().strip()
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}', literal):
            key = ('date', literal)
        else:
            key = ('percent' if literal.endswith('%') else 'number',
                   str(Decimal(literal.replace(',', '').replace('%', '').strip()).normalize()))
        tokens.append((literal, key, text.count('\n', 0, match.start()) + 1))
    return tokens


def audit_memo(memo, report):
    allowed = {key for _, key, _ in numeric_tokens(report)}
    return [{'number': literal, 'line': line} for literal, key, line in numeric_tokens(memo) if key not in allowed]


def run(ticker, out, user_agent=None, as_of=None, offline=False):
    ticker = ticker.strip().upper()
    if not re.fullmatch(r'[A-Z][A-Z0-9.-]{0,14}', ticker):
        raise ValueError('Use a valid ticker, such as COST or JPM.')
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    evidence = out.parent / 'evidence'
    evidence.mkdir(exist_ok=True)
    raw_path = evidence / f'{ticker}_companyfacts.json'
    metadata_path = evidence / f'{ticker}_download.json'
    if offline:
        raw = raw_path.read_bytes()
        metadata = json.loads(metadata_path.read_text(encoding='utf-8'))
        if hashlib.sha256(raw).hexdigest() != metadata['sha256']:
            raise ValueError('Saved SEC snapshot hash mismatch.')
    else:
        user_agent = user_agent or os.environ.get('SEC_USER_AGENT', '')
        tickers_raw = download(TICKERS_URL, user_agent)
        entries = json.loads(tickers_raw)
        match = next((v for v in entries.values() if v['ticker'].upper() == ticker), None)
        if match is None:
            raise ValueError(f'Ticker {ticker} not found in SEC ticker map.')
        url = FACTS_URL.format(cik=int(match['cik_str']))
        raw = download(url, user_agent)
        raw_path.write_bytes(raw)
        (evidence / 'company_tickers.json').write_bytes(tickers_raw)
        metadata = {'url': url, 'ticker_url': TICKERS_URL,
                    'retrieved_utc': datetime.now(timezone.utc).isoformat(),
                    'sha256': hashlib.sha256(raw).hexdigest()}
        metadata_path.write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    result = analyze(json.loads(raw), ticker, as_of or date.today().isoformat())
    result['source'] = metadata
    result_path = out / f'{ticker}_facts.json'
    result_path.write_text(json.dumps(result, indent=2), encoding='utf-8')
    report = report_text(result)
    (out / f'{ticker}_report.md').write_text(report, encoding='utf-8')
    return result, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('ticker')
    parser.add_argument('--out', type=Path, default=ROOT / 'outputs')
    parser.add_argument('--as-of', default=None)
    parser.add_argument('--offline', action='store_true')
    parser.add_argument('--audit-memo', type=Path)
    args = parser.parse_args()
    if args.as_of:
        date.fromisoformat(args.as_of)
    try:
        _, report = run(args.ticker, args.out, as_of=args.as_of, offline=args.offline)
        print(report)
        if args.audit_memo:
            flags = audit_memo(args.audit_memo.read_text(encoding='utf-8'), report)
            print('Memo numeric audit: ' + json.dumps(flags if flags else 'pass'))
            return 1 if flags else 0
    except (ValueError, OSError, KeyError, RuntimeError) as exc:
        parser.exit(2, f'{exc}\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
