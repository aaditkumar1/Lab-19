# AVUV company selection

Issuer portfolio holdings as of 11/04/2026; retrieved November 5, 2026.

Source: https://www.avantisinvestors.com/avantis-investments/en-us/avantis-us-small-cap-value-etf/

| Company | Weight |
|---|---:|
| GATX CORP COMMON STOCK USD.625 | 1.00% |
| LYFT INC A COMMON STOCK USD.00001 | 0.90% |
| MATSON INC COMMON STOCK | 0.90% |
| MACY S INC COMMON STOCK USD.01 | 0.81% |
| CROCS INC COMMON STOCK USD.001 | 0.81% |
| ABERCROMBIE + FITCH CO CL A COMMON STOCK USD.01 | 0.80% |
| LEAR CORP COMMON STOCK USD.01 | 0.71% |
| RUSH ENTERPRISES INC CL A COMMON STOCK USD.01 | 0.69% |
| CHEESECAKE FACTORY INC/THE COMMON STOCK USD.01 | 0.69% |
| CABOT CORP COMMON STOCK USD1.0 | 0.68% |

GATX is the largest company in the latest issuer table. The September quarterly fact sheet has Matson first; that older ranking is superseded for this run by the dated daily holdings. Raw issuer HTML and extraction metadata are saved alongside this file.
